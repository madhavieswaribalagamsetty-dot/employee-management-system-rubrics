const form = document.getElementById("employeeForm");
const table = document.getElementById("employeeTable");

async function loadEmployees() {

    const response = await fetch("/api/employees");
    const employees = await response.json();

    table.innerHTML = "";

    employees.forEach(employee => {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${employee.id}</td>
            <td>${employee.name}</td>
            <td>${employee.email}</td>
            <td>${employee.phone}</td>
            <td>${employee.department}</td>
            <td>${employee.role}</td>
            <td>₹${employee.salary}</td>
            <td>${employee.attendance}</td>

            <td>
                <button onclick="deleteEmployee(${employee.id})">
                    Delete
                </button>
            </td>
        `;

        table.appendChild(row);

    });
}


form.addEventListener("submit", async function(event) {

    event.preventDefault();

    const employee = {

        name: document.getElementById("name").value,

        email: document.getElementById("email").value,

        phone: document.getElementById("phone").value,

        department:
            document.getElementById("department").value,

        role:
            document.getElementById("role").value,

        salary:
            document.getElementById("salary").value,

        attendance:
            document.getElementById("attendance").value
    };

    await fetch("/api/employees", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(employee)

    });

    alert("Employee added successfully!");

    form.reset();

    loadEmployees();

});


async function deleteEmployee(id) {

    await fetch(`/api/employees/${id}`, {
        method: "DELETE"
    });

    alert("Employee deleted successfully!");

    loadEmployees();
}


loadEmployees();