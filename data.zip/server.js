const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("public"));

const dataFile = path.join(__dirname, "data", "employees.json");

function getEmployees() {
    if (!fs.existsSync(dataFile)) {
        return [];
    }

    return JSON.parse(fs.readFileSync(dataFile, "utf8"));
}

function saveEmployees(employees) {
    fs.writeFileSync(dataFile, JSON.stringify(employees, null, 2));
}

// Get all employees
app.get("/api/employees", (req, res) => {
    res.json(getEmployees());
});

// Add employee
app.post("/api/employees", (req, res) => {
    const employees = getEmployees();

    const employee = {
        id: Date.now(),
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        department: req.body.department,
        role: req.body.role,
        salary: req.body.salary,
        attendance: req.body.attendance || "Present"
    };

    employees.push(employee);
    saveEmployees(employees);

    res.json({
        message: "Employee added successfully",
        employee
    });
});

// Delete employee
app.delete("/api/employees/:id", (req, res) => {
    let employees = getEmployees();

    employees = employees.filter(
        employee => employee.id != req.params.id
    );

    saveEmployees(employees);

    res.json({
        message: "Employee deleted successfully"
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});